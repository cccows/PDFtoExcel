import pandas as pd
import re
import sys
from pathlib import Path

def extract_tables_from_markdown(markdown_text):
    """Extract tables from markdown text and return them as a list of pandas DataFrames."""
    # Split the markdown text by lines
    lines = markdown_text.strip().split('\n')
    
    tables = []
    current_table_lines = []
    in_table = False
    
    for line in lines:
        # Check if line contains pipe symbol (indicating table row)
        if '|' in line:
            # If we're not already in a table, we've found the start of one
            if not in_table:
                in_table = True
                current_table_lines = [line]
            else:
                current_table_lines.append(line)
        else:
            # If we were in a table and now hit a non-table line, process the table
            if in_table:
                if len(current_table_lines) > 2:  # Check if it's a valid table (header, separator, data)
                    tables.append(parse_markdown_table(current_table_lines))
                in_table = False
                current_table_lines = []
    
    # Don't forget to process the last table if we ended while still in one
    if in_table and len(current_table_lines) > 2:
        tables.append(parse_markdown_table(current_table_lines))
    
    return tables

def parse_markdown_table(table_lines):
    """Parse a markdown table into a pandas DataFrame."""
    # Remove the separator line (second line with dashes and pipes)
    if len(table_lines) > 1 and all(c in '|-:' for c in table_lines[1].strip()):
        header_line = table_lines[0]
        data_lines = table_lines[2:]
    else:
        header_line = table_lines[0]
        data_lines = table_lines[1:]
    
    # Process header
    headers = [cell.strip() for cell in header_line.split('|')]
    # Remove empty elements from start and end if they exist
    if headers[0] == '':
        headers = headers[1:]
    if headers[-1] == '':
        headers = headers[:-1]
    
    # Process data rows
    data = []
    for line in data_lines:
        cells = [cell.strip() for cell in line.split('|')]
        # Remove empty elements from start and end if they exist
        if cells[0] == '':
            cells = cells[1:]
        if cells[-1] == '':
            cells = cells[:-1]
        
        # Only add rows that have data
        if any(cell != '' for cell in cells):
            data.append(cells)
    
    # Create DataFrame
    try:
        df = pd.DataFrame(data, columns=headers)
        return df
    except ValueError as e:
        # Handle case where rows may have different number of cells
        max_columns = max(len(row) for row in data)
        padded_data = [row + [''] * (max_columns - len(row)) for row in data]
        headers = headers + [''] * (max_columns - len(headers))
        return pd.DataFrame(padded_data, columns=headers)

def convertToExcel(markdown_file):
    """Convert markdown tables to Excel file."""
    # Read markdown file
    with open(markdown_file, 'r', encoding='utf-8') as f:
        markdown_text = f.read()
    
    # Extract tables
    tables = extract_tables_from_markdown(markdown_text)
    
    if not tables:
        print(f"No tables found in {markdown_file}")
        return False
    
    # Create Excel file path
    excel_file = Path(markdown_file).with_suffix('.xlsx')
    
    # Create Excel writer
    with pd.ExcelWriter(excel_file) as writer:
        for i, table in enumerate(tables):
            # Create sheet name
            sheet_name = f"Table_{i+1}"
            
            # Write table to Excel sheet
            table.to_excel(writer, sheet_name=sheet_name, index=False)
    
    print(f"Successfully converted {len(tables)} tables from {markdown_file} to {excel_file}")
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: python mdToExcel.py input_markdown_file")
        return
    
    input_path = Path(sys.argv[1])
    
    if not input_path.exists():
        print(f"Error: Input file '{input_path}' not found.")
        return
    
    result = convertToExcel(input_path)

if __name__ == "__main__":
    main()